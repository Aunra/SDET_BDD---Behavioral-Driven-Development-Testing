package com.automation.stepdefination;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.en.*;


public class StepDefination {
	WebDriver driver=null;
	@Given("^User is on registration page$")
	public void user_is_on_registration_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","Drivers/chromedriver.exe");
		driver=new ChromeDriver();
	  driver.get("https://www.gillette.co.in/en-in/createprofilepage");
	  driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
	}

	@When("^User enter Firstname$")
	public void user_enter_Firstname() throws Throwable {
		driver.findElement(By.id("phdesktopbody_0_grs_consumer[firstname]")).sendKeys("Anuradha"); 
		
	}

	@When("^User enter Lastname$")
	public void user_enter_Lastname() throws Throwable {
		driver.findElement(By.id("phdesktopbody_0_grs_consumer[lastname]")).sendKeys("Yadav"); 
	}

	@When("^User enter Email$")
	public void user_enter_Email() throws Throwable {
		driver.findElement(By.id("phdesktopbody_0_grs_account[emails][0][address]")).sendKeys("Akhil2@gmail.com"); 
	}

	@When("^User enter Password$")
	public void user_enter_Password() throws Throwable {
		driver.findElement(By.id("phdesktopbody_0_grs_account[password][password]")).sendKeys("Akhil@1234");  
	}

	@When("^User enter confirm Password$")
	public void user_enter_confirm_Password() throws Throwable {
		driver.findElement(By.id("phdesktopbody_0_grs_account[password][confirm]")).sendKeys("Akhil@1234"); 
	}

	@When("^User enter Birthdate month$")
	public void user_enter_Birthdate_month() throws Throwable {
		Select Month = new Select(driver.findElement(By.id("phdesktopbody_0_grs_consumer[birthdate][month]")));
		 Month.selectByValue("10");
		 
	}

	@When("^User enter Birthdate Year$")
	public void user_enter_Birthdate_Year() throws Throwable {
		
	Select Year = new Select(driver.findElement(By.id("phdesktopbody_0_grs_consumer[birthdate][year]")));
		 Year.selectByValue("1988");
	}

	@When("^User enter Zipcode$")
	public void user_enter_Zipcode() throws Throwable {
		driver.findElement(By.id("phdesktopbody_0_grs_account[addresses][0][postalarea]")).sendKeys("201105");
	   
	}

	@When("^User click on checkbox$")
	public void user_click_on_checkbox() throws Throwable {
		driver.findElement(By.id("phdesktopbody_0_ctl44")).click();  
	}

	@When("^User click Create Your Profile$")
	public void user_click_Create_Your_Profile() throws Throwable {
		driver.findElement(By.id("phdesktopbody_0_submit")).click();  
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
	}

	@Then("^Account should be created$")
	public void account_should_be_created() throws Throwable {
		  boolean result= false;
		if (driver.getPageSource().contains("YOUR REGISTRATION IS COMPLETE")) {
			  result=true;
			  System.out.println("Registation complete");
			  driver.close();
		  }
	}

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		 driver.get("https://www.gillette.co.in/en-in/loginpage");
		  driver.manage().window().maximize();
			 driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
		driver.findElement(By.id("phdesktopbody_0_username")).sendKeys("Akhil2@gmail.com"); 
	}

	@When("^User enter email$")
	public void user_enter_email() throws Throwable {
		driver.findElement(By.id("phdesktopbody_0$ctl04")).sendKeys("Akhil@1234"); 
	}

	@When("^User click on sign-in$")
	public void user_click_on_sign_in() throws Throwable {
		driver.findElement(By.id("phdesktopbody_0_Sign In")).click();; 
	}

	@Then("^User should be signed in$")
	public void user_should_be_signed_in() throws Throwable {
		  boolean result= false;
			if (driver.getPageSource().contains("YOUR PROFILE")) {
				  result=true;
				  System.out.println("Sign-in Successfully");
				  driver.close();
			  }
	}
	@Given("^Launch Goibibo website$")
	public void launch_Goibibo_website() throws Throwable {
		driver=new ChromeDriver();
		  driver.get("https://www.goibibo.com/");
		  driver.manage().window().maximize();
			 driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);  
	}

	@When("^Select any one option\\( Oneway ,Roundtrip,Multi City\\)$")
	public void select_any_one_option_Oneway_Roundtrip_Multi_City() throws Throwable {
		driver.findElement(By.id("oneway")).click(); 
	}
	  
	

	@When("^Select From & Destination$")
	public void select_From_Destination() throws Throwable {
		driver.findElement(By.id("gosuggest_inputSrc")).click();
		driver.findElement(By.xpath("//*[@placeholder='From']")).sendKeys("DEL");
		driver.findElement(By.xpath("//p[contains(text(),'Delhi (DEL)')]")).click();
		driver.findElement(By.id("gosuggest_inputDest")).click();
		driver.findElement(By.xpath("//*[@placeholder='Destination']")).sendKeys("DEL");
		driver.findElement(By.xpath("//p[contains(text(),'Gorakhpur (GOP)')]")).click();
	}

	@When("^Select the Departure date - future Date$")
	public void select_the_Departure_date_future_Date() throws Throwable {
		driver.findElement(By.xpath("//div[@aria-label='Wed Oct 21 2020']")).click();  
	}

	@When("^Select the traveller details and travel class$")
	public void select_the_traveller_details_and_travel_class() throws Throwable {
		driver.findElement(By.id("pax_label")).click();
		driver.findElement(By.id("pax_close")).click();
		driver.findElement(By.id("gi_search_btn")).click();
	}

	@When("^Search for the cheapest price and click on Book now button$")
	public void search_for_the_cheapest_price_and_click_on_Book_now_button() throws Throwable {
		driver.findElement(By.xpath("//input[@value='BOOK']")).click(); 
	}

	@Then("^Review the selection in the review page$")
	public void review_the_selection_in_the_review_page() throws Throwable {
		
		  boolean result= false;
			if (driver.getPageSource().contains("Ticket Details")) {
				  result=true;
				  System.out.println("Review Done");
			  } 


}
	}
